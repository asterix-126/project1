import mayflower.*;
public class Mario extends MovableAnimatedActor
{
    private Animation idleRight, idleLeft,  climb, walkRight, walkLeft, jumpRight, jumpLeft;
    private int lives, score, level;
    public Mario()
    {
        String[] idleFiles = new String[2];
        for (int i = 0; i<idleFiles.length; i++)
        {
           idleFiles[i] = new String("characters/mario/idle(" + (i) + ").png"); 
        }
        idleRight = new Animation(50, idleFiles);
        
        String[] walkFiles = new String[3];
        for (int i = 0; i<walkFiles.length; i++)
        {
           walkFiles[i] = new String("characters/mario/walk(" + (i) + ").png"); 
        }
        
        String[] jumpFiles = new String[1];
        for (int i = 0; i<jumpFiles.length; i++)
        {
           jumpFiles[i] = new String("characters/mario/jump(" + (i) + ").png"); 
        }
        jumpRight = new Animation(50, jumpFiles);
        
        walkLeft = new Animation(50, walkFiles);
        walkLeft.mirrorHorizontally();
        
        idleLeft = new Animation(50, idleFiles);
        idleLeft.mirrorHorizontally();
        
        jumpLeft = new Animation(50, jumpFiles);
        jumpLeft.mirrorHorizontally();

        //walkRight.scale(32, 32);
        //walkLeft.scale(32, 32);
        //idleRight.scale(32, 32);
        //idleLeft.scale(32, 32);
        //jumpRight.scale(32,32);
        //jumpLeft.scale(32,32);
        //climb.scale(32, 32);
        
        setWalkRightAnimation(walkRight);
        setWalkLeftAnimation(walkLeft);
        setIdleRightAnimation(idleRight);
        setIdleLeftAnimation(idleLeft);
        setJumpRightAnimation(jumpRight);
        setJumpLeftAnimation(jumpLeft);
        setClimbAnimation(climb);
        
        setAnimation(idleRight);
        
    }
}
