import mayflower.*;
public class Level1 extends World
{
    
    private Mario mario;
    
    public Level1()
    {
        setBackground("characters/backgrounds/LevelOneBackground.jpg");
        String[][] tiles = new String[9][12]; //try 7 by 4 later
        buildLevel1(tiles);
        mario = new Mario();
        addObject(mario, 100,100);
        
    }
    public void buildLevel1(String[][] tiles)
    {
        for( int i = 0; i < tiles.length; i++)
        {
            for( int j = 0; j < tiles[i].length; j++)
            {
                tiles[i][j] = "";
            }
        }
        for(int j = 0; j < tiles[8].length; j++)
        {
            tiles[8][j] = "ground";
        }
         for(int r = 0; r < tiles.length; r++)
        {
            for( int c = 0; c < tiles[r].length; c++)
            {
                if (tiles[r][c].equals("ground"))
                    {
                        addObject(new bricks(), c*84, r*80);
                    }
            }
        }
    }
    
    public void act()
    {
        
    }

}
